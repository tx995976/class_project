package main.spi.Imethod;

public interface method {
    public void show_version();
}
