package main.spi.provider;

import  main.spi.Imethod.method;
public class method1 implements method {

    public void show_version() {
        System.out.println("version 1.0");
    }
}
