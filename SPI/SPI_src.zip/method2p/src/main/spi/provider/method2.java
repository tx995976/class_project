package main.spi.provider;

import main.spi.Imethod.method;
public class method2 implements method {
    public void show_version() {
        System.out.println("version 2.0");
    }
}
